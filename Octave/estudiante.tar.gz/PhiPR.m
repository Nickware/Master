function Phi=PhiPR(T,P)

%butilacetato
Tc=[579,610.3];
Pc=[3140e3,3417e3];
W=[4.17000E-01,5.60000E-01];
R =8.314 ;% (J/mol-K)
Tr=T./Tc;
alpha = (1+(0.37464+1.54226*W-0.26992*W.^2).*(1-Tr.^0.5)).^2;
AAA =(0.45724*R^2*Tc.^2./Pc).*alpha;   
BBB = 0.0778*R*Tc./Pc; 
E= sqrt(2);
CPG= 1;
% Forma polinomica en terminos de Z 
AA=AAA*P/(R*T)^2;
BB=BBB*P/(R*T);

% Coeficientes de la funcion polinomica
aa=[1,1];
bb=1-BB;
cc=AA-3*BB.^2-2*BB;
dd=AA.*BB-BB.^2-BB.^3;

% Establecimiento del polinomio 
Pol2=[aa,-bb,cc,-dd];
% Diferenciacion de raices 
Raices1 = roots(Pol2);
raices1 = real(Raices1); 
% Reconocimiento de raices 
Zv= max(raices1);
Zl= min(raices1);
% Calculo de Phi y fugacidad
lnPhi = Zv-1-log(Zv-BB) - (AA./(2*E*BB))*log( (Zv+BB*(CPG+E))/(Zv+BB*(CPG-E)) );
Phi = exp(lnPhi);
end