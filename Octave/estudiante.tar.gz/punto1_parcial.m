clc
clear all
t(1)=0;
x(1)=2;
n=50;%%se evalua el método en el intervalo (0,n)
h=0.001;%%ta,año del paso
r=-2.9;%%valor constante r
f=@(x,t) r-x-exp(-x);
%%método RK4 
for i=1:n/h
    t(i+1)=t(i)+h;
    k1=h*(f(t(i),x(i)));
    k2=h*(f(t(i)+(h/2),x(i)+k1/2));
    k3=h*(f(t(i)+(h/2),x(i)+k2/2));
    k4=h*(f(t(i)+(h/2),x(i)+k3));
    
    x(i+1)=x(i)+(k1+2*k2+2*k3+k4)/6;
        
end
plot(t,x)
title('x vs t')