clc
clearvars
n=input('Divisiones ');
h=pi/(2*n);
Am=0;
for i=1:n
    Am=Am+h*(cos(-pi/2+(i-1)*h)+cos(-pi/2+i*h))/2;
end
disp(Am)