function [vertices, ndx] = primitiva(r, f, c)
%documentacion
% r radio
% f numero filas
% c numero columnas
% vertices la posción de todos los puntos
% ndx los indices de todos los triangulos
k = 1;

for i=0:f
    for j=0:c
        x(k) = r*cos(pi*i/f-pi/2)*cos(2*pi*j/c);
        y(k) = r*cos(pi*i/f-pi/2)*sin(2*pi*j/c);
        z(k) = r*sin(pi*i/f-pi/2);
        k = k+1;
        %plot3(x,y,z,'.');
        %axis([-r r -r r -r r])
        %grid
        %pause(0.01);
    end
end

k = 1;
for i=0:f-1
    for j=0:c-1
        n = i*(c+1)+j+1;
        ndx(k,1:3) = [n n+c+1 n+1];
        k = k+1;
        ndx(k,1:3) = [n+1 n+c+1 n+c+2];
        k = k+1;
        trisurf(ndx,x,y,z,z);
        axis([-r r -r r -r r])
        grid
        pause(0.01);
    end
end

ndx = ndx';
ndx = ndx(:);
vertices = [x' y' z']';
vertices = vertices(:);

