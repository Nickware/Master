clc
clear all
%%remplazando theta=x para facilitar la escritura del código'
%%d²x/dt²=-sin(x)-0.2*dx/dt+0.3*exp(-(0.2*t/10))*sin(2*t)
%%remplazando dx/dt = u entonces:
%% du/dt=-sin(x)-0.2*u+0.3*exp(-0.2*t/10)*sin(2*t)
t(1)=0;
x(1)=0.3;
u(1)=0;
n=50;
h=0.001;

f=@(t,x,u) u;
g=@(t,x,u) -sin(x)-0.2*u+0.3*exp(-(0.2*t/10))*sin(2*t);
%%método del punto medio
for i=1:n/h
    t(i+1)=t(i)+h;
    x(i+1)=x(i)+h*f(t(i)+(h/2),x(i)+(h/2)*f(t(i),x(i),u(i)),u(i)+(h/2)*g(t(i),x(i),u(i)));
    u(i+1)=u(i)+h*g(t(i)+(h/2),x(i)+(h/2)*f(t(i),x(i),u(i)),u(i)+(h/2)*g(t(i),x(i),u(i)));
end
plot(u,x)
title('dx/dt vs x')