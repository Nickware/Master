clc
clearvars
h=0.0001;
t(1)=0;
xRK(1)=1;
yRK(1)=2;

for i=1:3/h
    Kx1=h*(3*xRK(i)-xRK(i)*yRK(i));
    Kx2=h*(3*(xRK(i)+Kx1/2)-(xRK(i)+Kx1/2)*yRK(i));
    Kx3=h*(3*(xRK(i)+Kx2/2)-(xRK(i)+Kx2/2)*yRK(i));
    Kx4=h*(3*(xRK(i)+Kx3)-(xRK(i)+Kx3)*yRK(i));
    xRK(i+1)=xRK(i)+(Kx1+2*Kx2+2*Kx3+Kx4)/6;
    
    Ky1=h*(xRK(i)*yRK(i)-2*yRK(i));
    Ky2=h*(xRK(i)*(yRK(i)+Ky1/2)-2*(yRK(i)+Ky1/2));
    Ky3=h*(xRK(i)*(yRK(i)+Ky2/2)-2*(yRK(i)+Ky2/2));
    Ky4=h*(xRK(i)*(yRK(i)+Ky3)-2*(yRK(i)+Ky3));
    yRK(i+1)=yRK(i)+(Ky1+2*Ky2+2*Ky3+Ky4)/6;
end
plot(xRK,yRK)