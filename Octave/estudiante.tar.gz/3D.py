import numpy as np
import matplotlib.pyplot as plt

f = 2
d = 1
theta = 75
theta = theta*np.pi/180.0;

cube = np.array([[0,0,0],
		 [0,0,1],
		 [0,1,0],
		 [0,1,1],
		 [1,0,0],
		 [1,0,1],
		 [1,1,0],
		 [1,1,1]])
cube = cube-0.5

#Defino matriz intrinseca K
K =  np.array([[f,0,0],
	       [0,f,0],
	       [0,0,1]])


#Defino posicion de la camara 
C = d * np.array([[ np.sin(theta)],
	          [       0        ],
	          [-np.cos(theta)]])

#Defino matriz de rotacion
R=  np.array([[np.cos(theta) ,0, np.sin(theta)],
	      [       0      ,1,      0       ],
	      [-np.sin(theta),0, np.cos(theta)]])

#Defino vector de translacion
t = -np.dot(R,C)

#Crea matriz de puntos en coordenadas homogeneas
X = np.ones((4,8))
X[0:3,:] = cube.T

#Proyeccion x = K*[R|t]*X
P = np.dot(K,np.concatenate((R,t),axis=1))
x = np.dot(P,X)

#Extraer 2D
x[0,:] = x[0,:]/x[2,:]
x[1,:] = x[1,:]/x[2,:]
x = x[0:2,:]

#Dibujar
plt.xlim(-1,1)
plt.ylim(-1,1)
plt.hold(True)

plt.plot([x[0,0],x[0,1]],[x[1,0],x[1,1]],'b-')
plt.plot([x[0,0],x[0,2]],[x[1,0],x[1,2]],'b-')
plt.plot([x[0,3],x[0,1]],[x[1,3],x[1,1]],'b-')
plt.plot([x[0,3],x[0,2]],[x[1,3],x[1,2]],'b-')

plt.plot([x[0,4],x[0,5]],[x[1,4],x[1,5]],'r-')
plt.plot([x[0,4],x[0,6]],[x[1,4],x[1,6]],'r-')
plt.plot([x[0,7],x[0,5]],[x[1,7],x[1,5]],'r-')
plt.plot([x[0,7],x[0,6]],[x[1,7],x[1,6]],'r-')

plt.plot([x[0,0],x[0,4]],[x[1,0],x[1,4]],'g-')
plt.plot([x[0,1],x[0,5]],[x[1,1],x[1,5]],'g-')
plt.plot([x[0,2],x[0,6]],[x[1,2],x[1,6]],'g-')
plt.plot([x[0,3],x[0,7]],[x[1,3],x[1,7]],'g-')

plt.show()



