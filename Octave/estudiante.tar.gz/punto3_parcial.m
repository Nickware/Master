clc
clear all
t(1)=0;
x(1)=0;
u(1)=0;
v(1)=1;
n=1000;
h=0.001;

f=@(t,x,u,v) u;
g=@(t,x,u,v) v;
j=@(t,x,u,v) x*u-2.017*v-x;
%%método de euler
for i=1:n/h
    t(i+1)=t(i)+h;
    x(i+1)=x(i)+h*(f(t(i),x(i),u(i),v(i)));
    u(i+1)=u(i)+h*(g(t(i),x(i),u(i),v(i)));
    v(i+1)=v(i)+h*(j(t(i),x(i),u(i),v(i)));
end
plot(x,u)
title('dx/dt vs x')
