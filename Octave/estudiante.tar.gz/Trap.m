clc
clearvars
N=input('Número máximo de intervalos ');
for n=1:N
D=pi/n;
x=0;
A=0;
for i=1:n
    A=A+D*(sin(x)+sin(x+D))/2;
    x=x+D;
end
Area(n)=A;
end
for n=1:N-1
    e(n)=abs((Area(n+1)-Area(n))/Area(n+1));
end
figure
subplot(2,1,1)       
plot(Area)
title('Area')

subplot(2,1,2)      
plot(e)      
title('Error')