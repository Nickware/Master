clc
clearvars
h=input('Valor de h: ');
x(1)=1;
y(1)=0.7182818;
ye(1)=0.7182818;
yh(1)=0.7182818;
ym(1)=0.7182818;
yRK(1)=0.7182818;
for n=1:30
    x(n+1)=x(n)+h;
    y(n+1)=exp(x(n+1))-2*x(n+1)^2; % Analítico
    ye(n+1)=ye(n)+h*(2*x(n)^2-4*x(n)+ye(n)); % Euler
    k1=h*(2*x(n)^2-4*x(n)+yh(n));
    k2=h*(2*x(n+1)^2-4*x(n+1)+yh(n)+k1);
    yh(n+1)=yh(n)+(k1+k2)/2; % Heun
    k1=h*(2*x(n)^2-4*x(n)+ym(n));
    k2=h*(2*(x(n)+h/2)^2-4*(x(n)+h/2)+ym(n)+k1/2);
    ym(n+1)=ym(n)+k2;% Punto Medio
    k1=h*(2*x(n)^2-4*x(n)+yRK(n));
    k2=h*(2*(x(n)+h/2)^2-4*(x(n)+h/2)+yRK(n)+k1/2);
    k3=h*(2*(x(n)+h/2)^2-4*(x(n)+h/2)+yRK(n)+k2/2);
    k4=h*(2*x(n+1)^2-4*x(n+1)+yRK(n)+k3);
    yRK(n+1)=yRK(n)+(k1+2*k2+2*k3+k4)/6;% 
end
plot(x,y,x,ye,x,yh,x,ym,x,yRK,'*')
legend('Analitico','Euler','Heun','Punto Medio','RK4')