clc
clearvars
t(1)=0;
x(1)=3.01;
y(1)=2;
h=input('Tamaño del paso ');
for n=1:20000
    t(n+1)=t(n)+h;
    x(n+1)=x(n)+h*(x(n)*y(n)-2*x(n));
    y(n+1)=y(n)+h*(3*y(n)-x(n)*y(n));
end


%figure % new figure
ax1 = subplot(2,1,1); % top subplot
ax2 = subplot(2,1,2); % bottom subplot


plot(ax1,t,x,t,y)
legend(ax1,'x(y)','y(y)')
title(ax1,'Solución')
xlabel(ax2,'t')

plot(ax2,x,y)
title(ax2,'Diagrama de Fase')
ylabel(ax2,'y(t)')
xlabel(ax2,'x(t)')

%plot(t,x)
%plot(x,w)
