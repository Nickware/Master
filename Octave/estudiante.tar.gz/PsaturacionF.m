function Pvap=PsaturacionF(T)
% Calculo de la presion de saturacion por la correlacion de KDB
% Coeficientes de la ecuacion
A=[-9.5850,-13.143];
B=[-7790.088,-10874.67];
C=[80.709,108.9321];
D=[5.193475E-06,3.489983E-06];
% CALCULO DE PRESION DE VAPOR 
lnPvap= A*log(T)+B/T+C+D*T^2;
Pvap=exp(lnPvap)*1000;% Salida en Pa