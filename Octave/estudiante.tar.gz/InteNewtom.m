%Integrales Newton
function a = InteNewtom (f,c,b,m)
    %n = 1;
    %rn = [n];
    %ra = [0];
    %h = (b-c)/n;
    %xp= (c+h/2);
    %a = h*xp;
    %ra=[ra,a];
    %while (RelError(ra(end-1),ra(end))>t)
    a=0;
    ra = [];
    for j = 1:m
        h = (b-c)/j;
        xi=c+h;
        for i = 1:j
            xp= (xi+h/2);
            a = a + (h*f(xp));
            xi=xi+h;
        end 
        ra=[ra,a];
        disp(ra);
        a = 0;
    end
   rn = 1:1:m; 
   plot(rn,ra);
end

function e = RelError (m,n)
x1 = min(m,n);
x2 = max(m,n);
e  = abs((x2-x1)/x2);
end

