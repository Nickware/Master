clc
clearvars
L=1;
v=.3;
N=100;
k=100;
T=zeros(k*N,10*(N+1));
for i=2:N;
    T(1,i)=sin(pi*(i-1)/N);
    T(2,i)=T(1,i)-(pi*v/N)*cos(pi*(i-1)/N);
end;

for i=2:k*N-1;
    for j=2:10*(N+1)-1;
    T(i+1,j)=2*(1-v^2)*T(i,j)-T(i-1,j)+v^2*(T(i,j+1)+T(i,j-1));
    end
    %T(i+1,10*(N+1))=2*(1-v^2)*T(i,10*(N+1))-T(i-1,10*(N+1))+v^2*(T(i,1)+T(i,10*(N+1)-1));
    %T(i+1,1)=2*(1-v^2)*T(i,1)-T(i-1,1)+v^2*(T(i,2)+T(i,10*(N+1)));
end

for i=1:k*N
plot(T(i,:))
axis([1 10*(N+1) -1.1 1.1])
pause(.005)
end

