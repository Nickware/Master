clc
clearvars
x = -2:1/10000:2;
y=(1+exp(-2*x)).^(-1);
T1=.5+.5*x;
T3=T1-(1/6)*x.^3;
T5=T3+x.^5/120;
plot(x,y,x,T1,x,T3,x,T5)
legend('Analítica','T1','T3','T5')