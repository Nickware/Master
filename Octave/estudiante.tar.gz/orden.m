clearvars
clc
n=input('Ingrese un número de cuatro cifras ');
c=0;
for i=2:n-1
    if (mod(n,i)==0)
        c=c+1;
    end
end
if c>0
    fprintf('El número %d no es primo \n',n)
else
    fprintf('El número %d es primo \n',n)
end



