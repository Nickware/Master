clc
clearvars
n=input('Divisiones ');
h=pi/(2*n);
Am=0;
for i=1:n
    Am=Am+h*cos(-pi/2+(2*i-1)*h/2);
end
disp(Am)