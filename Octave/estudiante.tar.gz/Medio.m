clc
clearvars
N=20;
x(1)=10;
x(2)=20;
xa=x(1);
xb=x(2);
F1=(668.06/xa)*(1-exp(-0.14*xa))-40;
F2=(668.06/xb)*(1-exp(-0.14*xb))-40;
if F1*F2<0
    for i=3:N
        xp=(xa*((668.06/xb)*(1-exp(-0.14*xb))-40)-xb*((668.06/xa)*(1-exp(-0.14*xa))-40))/(((668.06/xb)*(1-exp(-0.14*xb))-40)-((668.06/xa)*(1-exp(-0.14*xa))-40));
        
        if ((668.06/xp)*(1-exp(-0.14*xp))-40)*((668.06/xb)*(1-exp(-0.14*xb))-40)<0
            xa=xp;
            x(i)=xp;
        end
        if ((668.06/xa)*(1-exp(-0.14*xa))-40)*((668.06/xp)*(1-exp(-0.14*xp))-40)<0
            xb=xp;
            x(i)=xp;
        end
        if ((668.06/xa)*(1-exp(-0.14*xa))-40)*((668.06/xp)*(1-exp(-0.14*xp))-40)==0
            x(i)=xp;
            fprintf('La raíz es %d\n',xp)
            break
        end
        
    end
end
for i=1:N-1
    E(i)=abs((x(i+1)-x(i))/x(i+1));
end
figure
subplot(2,1,1)       
plot(x)
title('Raíz')

subplot(2,1,2)      
plot(E)      
title('Error')