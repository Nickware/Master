clc
clearvars
h=.2;
x(1)=0;
y(1)=1;
ya(1)=1;
yh(1)=1;
ym(1)=1;
yRK(1)=1;
for i=1:4/h
    x(i+1)=x(i)+h;
    y(i+1)=y(i)+h*(-x(i)*y(i));
    ya(i+1)=exp(-(x(i+1))^2/2);
    yh(i+1)=yh(i)+(-x(i)*yh(i)-(x(i)+h)*(yh(i)-h*x(i)*yh(i)))*h/2;
    ym(i+1)=ym(i)-h*(x(i)+h/2)*(ym(i)-x(i)*ym(i)*h/2);
    K1=-h*x(i)*yRK(i);
    K2=-h*(x(i)+h/2)*(yRK(i)+K1/2);
    K3=-h*(x(i)+h/2)*(yRK(i)+K2/2);
    K4=-h*(x(i)+h)*(yRK(i)+K3);
    yRK(i+1)=yRK(i)+(K1+2*K2+2*K3+K4)/6
end

plot(x,y,x,ya,x,yh,x,ym,x,yRK)
legend('Euler','Analítico','Heun','P. Medio','RK-4')