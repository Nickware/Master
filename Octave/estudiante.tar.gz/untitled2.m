clc
clearvars
% Establecimiento de variables de entrada
%butilacetato-hexanol
T=input('Ingrese la temperatura supuesta en K: ');
y1=input('Ingrese la composicion del Componente 1: ');
y2= 1-y1;
y=[y1,y2];

% Suposiciones iniciales
Phi=[1,1];
Gama=[1,1];

%Calculo de presion de saturacion
Pvap=PsaturacionF(T);

%Calculo de P
P= 1/(sum(y.*Phi)/sum(Gama.*Pvap));

% Calculo de X1 y X2
x= (y.*Phi*P)./(Gama.*Pvap);

% Calculo de coeficiente de actividad
Gama=GammaF(T,x);

% Ajuste de P
P= 1/(sum(y.*Phi)./sum(x.*Gama.*Pvap));

% Funcion objetivo
fo=sum(x)-1;
toler= 1e-3;

while (abs(fo)>toler)
    Gaman=Gama;
    Pn=P;
    % Calculo de phi ( Llamado de funcion)
    Phi=PhiPR(T,P);
    
    % Calculo de x1 y x2
    x= (y.*Phi*P)./(Gama.*Pvap);
    
    % Normalizando x1 y x2
    x=x/sum(x);
    
    % Calculo de gamas corregidas
    Gama=GammaF(T,x);
    
    % funcion obj 2
    obj=Gama-Gaman;
    if(abs(obj(1))<toler && abs(obj(2))<toler )
        P=1/(sum(y.*Phi)/sum(x.*Gama.*Pvap));
        objP=Pn-P;
        if(abs(objP)<toler)
            break
        end
    end
    x= (y.*Phi*P)./(Gama.*Pvap);
    % Normalizando x1 y x2
    x=x/sum(x);
end
disp('RESULTADOS')
fprintf('Presión de rocio: %.2f Pa\n',P)
fprintf('Composición Butilacetato: %.4f\n',x(1))
fprintf('Composición Hexanol: %.4f\n',x(2))