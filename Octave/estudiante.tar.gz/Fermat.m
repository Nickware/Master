clc
clearvars
n=input('ingrese un número ')
x=ceil(sqrt(n));
y=x^2-n;
while (sqrt(y)~=floor(sqrt(y)))
    x=x+1;
    y=x^2-n;
end
fprintf('%d=%d x %d\n',n,x+sqrt(y),x-sqrt(y))
