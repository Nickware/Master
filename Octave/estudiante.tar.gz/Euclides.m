clc
clearvars
x=input('Primer número ');
y=input('Segundo número ');
while (x ~= y)
    if (x>y)
        x=x-y;
    else
        y=y-x;
    end
end
fprintf('El MCD es %d \n',x)

    