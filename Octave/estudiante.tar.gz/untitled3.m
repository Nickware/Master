clc
clearvars
for n=1:20
h=pi/n;
Ad(n)=0;
Ai(n)=0;
    for i=1:n
        Ad(n)=Ad(n)+h*sin((i*h)^2);
    end
end
plot(Ad)
