clc
clearvars
N=20;
T=zeros(N+1,N+1);
for i=1:N+1
    for j=1:N+1
        if (i-N/2)^2+(j-N/2)^2<N^2/14
            T(i,j)=100;
        end
    end
end
for k=1:100
for i=2:N
    for j=2:N
        T(i,j)=(T(i+1,j)+T(i-1,j)+T(i,j-1)+T(i,j+1))/4;
    end
    T(1,i)=(T(2,i)+T(N+1,i)+T(1,i-1)+T(1,i+1))/4;
    T(N+1,i)=(T(1,i)+T(N,i)+T(N+1,i-1)+T(N+1,i+1))/4;
    T(i,1)=(T(i,2)+T(i,N+1)+T(i+1,1)+T(i-1,1))/4;
    T(i,N+1)=(T(1,i)+T(N,i)+T(N+1,i-1)+T(N+1,i+1))/4;
end
    T(1,1)=(T(2,1)+T(N+1,1)+T(1,N+1)+T(1,2))/4;
    T(N+1,1)=(T(1,1)+T(N,1)+T(N+1,N+1)+T(N+1,2))/4;
    T(1,N+1)=(T(N+1,2)+T(N+1,N+1)+T(1,1)+T(N,1))/4;
    T(N+1,N+1)=(T(1,N+1)+T(N,N+1)+T(N+1,N)+T(N+1,1))/4;
mesh(T)
axis([1 N+1 1 N+1 0 100])
pause(.1)
end