function Gama=GammaF(Tin,x)
% METODO UNIQUAC
% PARAMETROS 

Z=10;
r=[4.8274,4.803];
q=[4.196,4.132];
q2=[q(1),1.78];
R =8.314 ;% (J/mol-K)
% Calculo de L
l= (Z/2)*(r-q)-(r-1);
% Calculo de phi Mayuscula
PM= (r.*x)./sum(r.*x);
% Calculo de teta 
Teta= (q.*x)./sum(q.*x);
%Calculo de teta prima 
Teta2=(q2.*x)./sum(q2.*x);
% Establecimiento de parametros para la aij aji 
a= [0,1001.21;-421.79,0];%a->J*mol

% calculo de tao
TAO=exp(-a/(R*Tin));
% CALCULO DEL COEFICIENTE DE ACTIVIDAD 
lnGama1= log(PM(1)/x(1))+(Z/2)*q(1)*log(Teta(1)/PM(1))+l(1)-(PM(1)/x(1))*(x(1)*l(1)+x(2)*l(2))-q2(1)*log(Teta2(1)*TAO(1,1)+Teta2(2)*TAO(2,1))+q2(1)...
    -q2(1)*(Teta2(1)*TAO(1,1)/(Teta2(1)*TAO(1,1)+Teta2(2)*TAO(2,1))+Teta2(2)*TAO(1,2)/(Teta2(1)*TAO(1,2)+Teta2(2)*TAO(2,2)));
lnGama2= log(PM(2)/x(2))+(Z/2)*q(2)*log(Teta(2)/PM(2))+l(2)-(PM(2)/x(2))*(x(1)*l(1)+x(2)*l(2))-q2(2)*log(Teta2(1)*TAO(1,2)+Teta2(2)*TAO(2,2))+q2(2)...
    -q2(2)*(Teta2(1)*TAO(2,1)/(Teta2(1)*TAO(1,1)+Teta2(2)*TAO(2,1))+Teta2(2)*TAO(2,2)/(Teta2(1)*TAO(1,2)+Teta2(2)*TAO(2,2))); 
Gama= [exp(lnGama1),exp(lnGama2)];
end