clc
clearvars
for n=1:30
h=1/n;
x(1)=0;
y(1)=1;
ya(1)=1;
for i=1:5/h
    x(i+1)=x(i)+h;
    y(i+1)=y(i)+h*(-x(i)*y(i));
    ya(i+1)=exp(-(x(i+1))^2/2);
end

plot(x,y,x,ya)
legend('Euler','Analítico')
pause(0.7)
end