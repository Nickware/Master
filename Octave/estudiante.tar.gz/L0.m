clc
clearvars
N=4;
T=zeros(N);
for j=2:N-1
    T(j,N)=30;
    T(1,j)=50;
    T(j,1)=-100;
end
T

for n=1:8
 for i=2:N-1
     for j=2:N-1
        T(i,j)=(T(i+1,j)+T(i-1,j)+T(i,j+1)+T(i,j-1))/4;
        end
 end
 T
end
 T
mesh(T)