clc
clearvars
N=input('Número mayor: ');
for j=2:N
    x(j-1)=j;
end

for j=1:N-1
    if x(j)>0
        for k=j+1:N-1
            if mod(x(k),x(j))==0
                x(k)=0;
            end
        end
    end
end
x
k=1;
for j=1:N-1
    if x(j)>0
        P(k)=x(j);
        k=k+1;
    end
end
fprintf('Los primos hasta %d son: ',N)
disp(P)