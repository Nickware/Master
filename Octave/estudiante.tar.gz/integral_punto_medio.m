%Algoritmo para calcular el valor de la integral
%El valor de la integral por este metodo se obtiene aproximadeamente para
%un número de particiones de 40
clc
clearvars
n=input('Indique el número de particiones');
for j=1:n
x=0;   
h=40/j;
area=0;

for i=1:j
    x1=x+h;
    x2=x1-(h/2);
    area=area + h*(exp(-x2/3))*cos(x2); 
    error(i)=abs(x1-x)/x;
    x=x1;
end
t(j)=area;
err(j)=error(j);

end
figure
subplot(2,1,1)
plot(t)
title('Area vs particiones')
subplot(2,1,2)
plot(err)
title('Error vs particiones')
fprintf('El valor de la integral es %d\n',area)
