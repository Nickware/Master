
clc; 
clearvars

v = 1  ;
L = 200 ;


h = input('size of interval: ');
T = input('max time value: ');

m = L/h;
H = zeros(m + 1,5*m+1,T);

for k=2:m
    for l=2:m
        H(k,l,1) = sin((pi*h*(k-1))/L)*sin((pi*h*(l-1))/L);
        H(k,l,2) = H(k,l,1) + h*(-v*pi/L)*(cos(pi*h*(k-1)/L))*sin((pi*h*(l-1))/L);
    end
end

  


for t=2:T-1
   %H(t+1,1) = (v^2)*(H(t,2)+H(t,5*m+1)-2*H(t,1))- H(t-1,1)+2*H(t,1);
   for x=2:5*m-1
       for y=2:m
           H(x,y,t+1) = 2*H(x,y,t) - H(x,y,t-1) + (v^2)*(H(x+1,y,t)+H(x-1,y,t)-4*H(x,y,t) +  H(x,y+1,t)+H(x,y-1,t)     );
           %H(x,y,t+1) = (v^2)*(H(t,x+1)+H(t,x-1)-2*H(t,x))- H(t-1,x)+2*H(t,x);
       end
   end
   %H(t+1,5*m+1) = (v^2)*(H(t,1)+H(t,5*m)-2*H(t,5*m+1))- H(t-1,5*m+1)+2*H(t,5*m+1);
   
   
   mesh(H(:,:,t))
   axis([1 5*m+1 1 m+1 -1 1])
   pause(.01)
end
