clc
clearvars
L=100;
v=1;
N=20;
k=1000;
T=zeros(N,N+1);
for i=2:N;
    T(1,i)=sin(pi*(i-1)/N);
    T(2,i)=sin(pi*(i-1)/N);
end;

for i=2:k*N-1;
    for j=2:(N+1)-1;
        T(i+1,j)=2*(1-v^2)*T(i,j)-T(i-1,j)+v^2*(T(i,j+1)+T(i,j-1));
    end
    plot(T(i,:))
    axis([1 N+1 -1.1 1.1])
    pause(.5)
end


