clc
clearvars
x = -2:1/10000:2;
y=exp(x);
T1=1+x;
T2=T1+(1/2)*x.^2;
T3=T2+x.^3/6;
T4=T3+x.^3/24;
plot(x,y,x,T1)
legend('Analítica','T1')
plot(x,y,x,T1,x,T2)
legend('Analítica','T1','T2')
plot(x,y,x,T1,x,T2,x,T3)
legend('Analítica','T1','T2','T3')
plot(x,y,x,T1,x,T2,x,T3,x,T4)
 

legend('Analítica','T1','T2','T3','T4')