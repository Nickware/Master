clc
clearvars
N=4;
A=zeros(N);
Y=zeros(N,1);
Y(1)=-50;
Y(2)=80;
Y(3)=-100;
Y(4)=30;
for j=1:4
   A(j,j) =4;
end
for j=2:N-1
    A(1,j)=-1;
    A(N,j)=-1;
    A(j,1)=-1;
    A(j,N)=-1;
end
A
B=inv(A)
A*B
B*A
Y
B*Y