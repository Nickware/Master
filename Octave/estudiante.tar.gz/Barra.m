clc
clearvars
m=60000;
L=100;
k=.3;
N=50;
h=L/N;
T=zeros(m,N)
for j=2:N-1
    T(1,j)=-10;
end

for j=1:m;
    T(j,1)=-20;
    T(j,N)=80;
end
for i=1:m-1
    for j=2:N-1
      T(i+1,j)=(T(i,j+1)+T(i,j-1))*k/h+(1-2*k/h)*T(i,j);
    end
end
T
for j=1:m
    plot(T(j,:))
    pause(.05)
end