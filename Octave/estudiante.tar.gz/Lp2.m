clc
clearvars
N=100;
T=zeros(N)
for j=2:N-1
    T(j,N)=-10;
    T(1,j)=100;
    T(N,j)=35;
end
T
for n=1:1000
for i=2:N-1
    for j=2:N-1
        T(i,j)=(T(i+1,j)+T(i-1,j)+T(i,j+1)+T(i,j-1))/4;
    end
end
T
mesh(T)
pause(.1)
end
