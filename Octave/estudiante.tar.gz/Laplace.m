clc
clearvars
L=1;
a=.1;
N=10;
h=L/(N-1)
T=zeros(2*N,N);
fprintf('Matriz con ceros:\n')
disp(T)
for i=2:N;
    T(1,i)=100*sin(pi*(i-1)/(N-1));
end;
fprintf('Matriz con frontera definida:\n')
disp(T)

for i=1:2*N-1;
    for j=2:N-1;
    T(i+1,j)=(1-2*a/h)*T(i,j)+(T(i,j-1)+T(i,j+1))*a/h;
    end
end
disp(T)
%mesh(T)
for i=1:2*N
plot(T(i,:))
axis([1 10 0 100])
pause(.5)
end

