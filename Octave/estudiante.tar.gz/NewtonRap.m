%NewtonRaphson
function r = NewtonRap (f,p0,t)
    
    r = [p0];
    df = diff(f);
    p = p0 - (subs(f,p0))/(subs(df,p0));
    
    while (RelError(p,p0)>t)
        
        r = [r,p];
        p0 = p;
        p = p0 - (subs(f,p0))/(subs(df,p0));
        disp(r);
    end
end

function e = RelError (m,n)
x1 = min(m,n);
x2 = max(m,n);
e  = abs(x2-x1);
end
