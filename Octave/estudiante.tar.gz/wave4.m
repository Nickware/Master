clc; 
clearvars

v = 1  ;
L = 200 ;


h = input('size of interval: ');
T = input('max time value: ');

m = L/h;
H = zeros(T,5*m + 1);

for k=2:m
    H(1,k) = sin((pi*h*(k-1))/L);
    H(2,k) = H(1,k) + h*(-v*pi/L)*(cos(pi*h*(k-1)/L));
end
  

for t=2:T-1
   H(t+1,1) = (v^2)*(H(t,2)+H(t,5*m+1)-2*H(t,1))- H(t-1,1)+2*H(t,1);
   for x=2:5*m
        H(t+1,x) = (v^2)*(H(t,x+1)+H(t,x-1)-2*H(t,x))- H(t-1,x)+2*H(t,x);
   end
   H(t+1,5*m+1) = (v^2)*(H(t,1)+H(t,5*m)-2*H(t,5*m+1))- H(t-1,5*m+1)+2*H(t,5*m+1);
   
   
   plot(H(t+1,:))
   axis([1 5*m+1 -1 1])
   display(t+1);
   pause(.01)
end


