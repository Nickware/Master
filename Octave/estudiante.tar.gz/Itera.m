clc
clearvars
N=input('Número de iteraciones ')
x(1)=input('Valor inicial ')

    for i=1:N-1
        x(i+1)=(668.06/x(i))*(1-exp(-0.14*x(i)))-40+x(i);      
    end

for i=1:N-1
    E(i)=abs((x(i+1)-x(i))/x(i+1));
end
figure
subplot(2,1,1)       
plot(x)
title('Raíz')

subplot(2,1,2)      
plot(E)      
title('Error')