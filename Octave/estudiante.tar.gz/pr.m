clc
n=input('Inserte un número ');
k=0;
for j=2:n-1
    if mod(n,j)==0
        k=k+1;
    end
end
if k>0
    fprintf('%d NO es primo! \n',n)
else
    fprintf('%d es primo!\n',n)
end