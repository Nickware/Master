%Algoritmo para calcular la suma de los cuadrados de los digitos que
%componen un número de hasta 5 cifras
clc
clearvars
A=input('Igrese un número de hasta 5 cifras');
x1=(mod(A,10000));
x2=(mod(A,1000));
x3=(mod(A,100));
x4=(mod(A,10));
if A<10
    sumacuadrados=(A^2);
elseif A<100
    sumacuadrados=((A-x4)/10)^2+(x4^2);
elseif A<1000
    sumacuadrados=(((A-x3)/100)^2)+(((x3-x4)/10)^2)+(x4^2);
elseif A<10000
    sumacuadrados=(((A-x2)/1000)^2)+(((x2-x3)/100)^2)+(((x3-x4)/10)^2)+(x4^2);
elseif A<100000
    sumacuadrados=((((A-x1))/10000)^2)+(((x1-x2)/1000)^2)+(((x2-x3)/100)^2)+(((x3-x4)/10)^2)+(x4^2);
end

sumacuadrados