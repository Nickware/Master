function a = Trapecio(f,c,d,n)
    a= 0;
    h=(d-c)/n;
    xi=c;
    for i = 1:n
        %xp= (xi+h/2);
        a = a + ((h*(f(xi)+f(xi+h)))/2);
        xi=xi+h;
    end 
       
end