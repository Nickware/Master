clc
n=input('primer número ');
m=input('segundo número ');
A=n;
B=m;
while (A~=B)
if (A>B)
    A=A-B;
else
    B=B-A;
end
end

fprintf('El MCD entre %d y %d es %d \n',n,m,A)
fprintf('El MCM entre %d y %d es %d \n',n,m,n*m/A)