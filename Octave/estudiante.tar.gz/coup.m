clc
clearvars
h=0.001;
t(1)=0;
x(1)=1;
y(1)=0;
for i=1:20/h
    t(i+1)=t(i)+h;
    x(i+1)=x(i)+h*(y(i));
    y(i+1)=y(i)+h*(-x(i));
end
figure
subplot(2,1,1)       
plot(t,x,t,y)
legend('x','dx/dt')

subplot(2,1,2)      
plot(x,y)      
title('Diagrama de fase')

