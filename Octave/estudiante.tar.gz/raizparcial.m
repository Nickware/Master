%cálculo de la raiz de la función del punto 2 del parcial por el método del
%punto falso, se tomaron como valores iniciales -1 y 0
clc
clearvars
xa=-1;
xb=0;
fa=(xa^3)+(1/((xa^2)+(1/2)))^(1/2);
fb=(xb^3)+(1/((xb^2)+(1/2)))^(1/2);
t(1)=fa;
t(2)=fb;
n=input('Ingrese el número de cálculos a realizar');
error(1)=abs((xb-xa)/xb);
if fa*fb<0
for i=1:n
    xf=(xa*fb-xb*fa)/(fb-fa);
    ff=(xf^3)+(1/((xf^2)+(1/2)))^(1/2);
    if fa*ff<0
        xb=xf;
        t(i)=xb;
        error(i+1)=abs((xf-xa)/xf);
    end
    if fb*ff<0
        xa=xf;
        t(i)=xa;
        error(i+1)=abs((xf-xb)/xf);
    end 
end
end

fprintf('La raiz del función es %d\n',xf)
figure
subplot(2,1,1)
plot(t)
title('Raiz método punto falso')
subplot(2,1,2)
plot(error)
title('Error método punto falso')

