clc
X(1)=input('Ingrese primer valor ');
X(2)=input('Ingrese segundo valor ');
X(3)=input('Ingrese tecer valor ');
if(X(1)>X(2) && X(1)>X(3))
    mayor=X(1)
else
    if(X(2)>X(1) && X(2)>X(3))
        mayor=X(2)
    else
        if (X(3)>x(1) && X(3)>X(2))
                        mayor=X(3)
        else mayor=X(1)
    end
    end
end