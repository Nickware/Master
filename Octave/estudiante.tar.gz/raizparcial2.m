%Algoritmo para calcular la raiz de la función por el método de bisección.
%Se tomaron como valores iniciales -1 y 0  
clc
clearvars
x0=-1;
x1=0;
f0=(x0^3)+(1/((x0^2)+(1/2)))^(1/2);
f1=(x1^3)+(1/((x1^2)+(1/2)))^(1/2);
r(1)=f0;
r(2)=f1;
N=input('Ingrese el número de cálculos a realizar');
err(1)=abs((x1-x0)/x0);
if f0*f1<0
    
for j=1:N
    xp=((x0+x1)/2);
    fp=(xp^3)+(1/((xp^2)+(1/2)))^(1/2);
    if f0*fp<0
        x1=xp;
        r(j)=x1;
        err(j+1)=abs((xp-x0)/xp);
    end
    if f1*fp<0
        x0=xp;
        r(j)=x0;
        err(j+1)=abs((xp-x1)/xp);
    end 
end
end
fprintf('La raiz del función es %d\n',xp)
figure
subplot(2,1,1)
plot(r)
title('Raiz método bisección')
subplot(2,1,2)
plot(err)
title('Error método bisección')
