clc
clearvars
x(1)=input('Valor inicial ');
n=input('Número de pasos ')
for j=1:n
    x(j+1)=vpa(acos(log(x(j))),10);
    e(j)=abs(vpa((x(j+1)-x(j))/x(j+1),10));
end
plot(x)
vpa(x(n+1),10)
vpa(e(n),10)