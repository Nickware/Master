clc
clearvars
x(1)=input('Valor inicial ');
E=1;
j=1;
while (E>10^-6)
    x(j+1)=x(j)-(log(x(j))-cos(x(j)))/(1/x(j)+sin(x(j)));
    e(j)=abs((x(j+1)-x(j))/x(j+1));
    E=e(j);
    j=j+1;
end
figure
plot(e)
disp(x(j))
disp(j)