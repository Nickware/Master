%Metodo de Punto Falso
function r = FindRoot2 (f,a,b,t)
    x1 = min(a(1),b(1));
    x2 = max(a(2),b(2));    
    r = [x1,x2];
    while (RelError(r(end-1),r(end))>t)
        xp = LinearX([x1,f(x1)],[x2,f(x2)]);
         if (f(x1)*f(xp) < 0) 
            x2 = xp;
            r=[r,xp];
        elseif (f(xp)*f(x2) < 0)
            x1 = xp;
            r=[r,xp];
         else
            r=[r,xp];
            break;
         end      
    end
end



function x = LinearX (a,b)
    m = (b(2)-a(2))/ (b(1)-a(1));
    c = b(2) - m*b(1);
    x = -c/m;
end

function e = RelError (m,n)
x1 = min(m,n);
x2 = max(m,n);
e  = abs((x2-x1)/x2);
end