%Butilacetato y Hexanol

T=input('Ingrese la temperatura supuesta en K :');

for y1=0.01:0.01:0.99
    y=[y1,1-y1];
    [P,x]=ProcioF(T,y);
    plot(x(1),P,'b.',y(1),P,'r.')
    legend('Linea de burbuja','Linea de rocio')
    ylabel('Presion(Pa)')
    xlabel('x1-y1')
    title('Equilibrio P-xy')
    hold on
    grid on

end