if(1>3)
    t = linspace(0,10,4);
else
    t = linspace(0,5,4);
end

y=0;
for i=1:10
    y= i*5
end