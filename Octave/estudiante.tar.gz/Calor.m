clc
clearvars
k=50;
D=.2;
h=1;
for r=1:20
T=zeros(41,21,k);
for i=4:6
    for j=8:12
        T(i,j,1)=5;
    end
end

for i=25:30
    for j=10:15
        T(i,j,1)=20;
    end
end
mesh(T(:,:,1))
    axis([1 21 1 41 0 20])
    
for m=1:k-1
for i=2:40
    for j=2:20
        T(i,j,m+1)=T(i,j,m)+(T(i,j+1,m)+T(i,j-1,m)+T(i+1,j,m)+T(i-1,j,m)-4*T(i,j,m))*D/h;
    end
     mesh(T(:,:,m))
     axis([1 21 1 41 0 20])
     pause(.01)
end
end
end


